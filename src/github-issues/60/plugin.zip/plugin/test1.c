#include "stplugin.h"

int main()
{
    return(0);
}

int WinMain()
{
    return(0);
}

STDLL stata_call(int argc, char *argv[])
{
    SF_display("Hello World\n") ;
    return(0) ;
}
